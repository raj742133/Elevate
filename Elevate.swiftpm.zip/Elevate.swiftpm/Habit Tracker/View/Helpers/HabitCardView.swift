import SwiftUI

struct HabitCardView: View {
    var animationID: Namespace.ID
    var habit: Habit
    @Environment(\.modelContext) private var context
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header with name and progress
            HStack(alignment: .top, spacing: 15) {
                // Icon/Initial Circle
                Circle()
                    .fill(.orange.gradient.opacity(0.2))
                    .frame(width: 45, height: 45)
                    .overlay {
                        Text(habit.name.prefix(1).uppercased())
                            .font(.title3.bold())
                            .foregroundStyle(.orange)
                    }
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(habit.name)
                        .font(.title3)
                        .fontWeight(.semibold)
                    
                    // Frequency display
                    HStack(spacing: 4) {
                        Text(formatFrequency())
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        
                        if !habit.notificationIDs.isEmpty {
                            Image(systemName: "bell.fill")
                                .font(.caption2)
                                .foregroundStyle(.orange)
                        }
                    }
                }
                
                Spacer()
                
                // Progress Circle
                CompletionProgressIndicator()
            }
            
            // Today's status if applicable
            if habit.frequencies.contains(where: { $0.rawValue == Date.now.weekDay }) {
                todayStatusView
            }
        }
        .padding(15)
        .background(.background, in: .rect(cornerRadius: 15))
        .shadow(color: .black.opacity(0.05), radius: 5, y: 2)
        .matchedTransitionSource(id: habit.uniqueID, in: animationID)
    }
    
    private func formatFrequency() -> String {
        let days = habit.frequencies.map { $0.rawValue.prefix(3) }.joined(separator: ", ")
        return "Every \(days)"
    }
    
    @ViewBuilder
    private var todayStatusView: some View {
        if !habit.completedDates.contains(Date.now.startOfDay.timeIntervalSince1970) {
            Button {
                withAnimation(.snappy) {
                    let todayTimeStamp = Date.now.startOfDay.timeIntervalSince1970
                    habit.completedDates.append(todayTimeStamp)
                }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "circle")
                        .imageScale(.small)
                    Text("Mark Today Complete")
                        .font(.callout)
                }
                .foregroundStyle(.orange)
            }
            .padding(.top, 5)
        } else {
            HStack(spacing: 8) {
                Image(systemName: "checkmark.circle.fill")
                    .imageScale(.small)
                Text("Completed Today")
                    .font(.callout)
            }
            .foregroundStyle(.green)
            .padding(.top, 5)
        }
    }
    
    @ViewBuilder
    func CompletionProgressIndicator() -> some View {
        let habitMatchingDatesInThisMonth = Date.datesInThisMonth.filter { date in
            habit.frequencies.contains {
                $0.rawValue == date.weekDay
            } && date.startOfDay >= habit.createdAt.startOfDay
        }
        
        let habitsCompletedInThisMonth = habitMatchingDatesInThisMonth.filter {
            habit.completedDates.contains($0.timeIntervalSince1970)
        }
        
        let progress = CGFloat(habitsCompletedInThisMonth.count) / CGFloat(habitMatchingDatesInThisMonth.count)
        let isComplete = !habitMatchingDatesInThisMonth.isEmpty && progress >= 1.0
        
        ZStack {
            Circle()
                .stroke(.quaternary, lineWidth: 4)
                .frame(width: 32, height: 32)
            
            Circle()
                .trim(from: 0, to: progress)
                .stroke(.orange.gradient, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .frame(width: 32, height: 32)
            
            if isComplete {
                Image(systemName: "checkmark")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.orange)
            }
        }
    }
}
